INSERT INTO `users` (`id_user`, `name`, `last_name`, `email`, `password`) VALUES (1, 'administrador', '0', 'admin@insutrendy.com', '$2y$10$euqXFwNkEL6GmI6/ElVuCOBz9CJJRknWAfDJJPZ4ZDq60CDYIb5RW');
