<?php $__env->startSection('content'); ?>
    

        
     <br><br>

      <?php $__env->stopSection(); ?>
      
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\insutrendy\webapp\resources\views/admin/index.blade.php ENDPATH**/ ?>